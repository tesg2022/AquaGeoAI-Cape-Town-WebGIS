# ===========================================================================
# AquaGeoAI Cape Town — Expanded WebGIS Application (GitHub Version)
# ===========================================================================

import datetime as dt
import math
import ee
import folium
import pandas as pd
import streamlit as st
from streamlit_folium import st_folium
import geemap.foliumap as geemap

# ---------------------------------------------------------------------------
# Configuration & Datasets
# ---------------------------------------------------------------------------

APP_NAME = "AquaGeoAI Cape Town"
APP_SUBTITLE = "GeoAI-Powered Water and Climate Intelligence"
AOI_ASSET = "projects/ee-ttgintamo/assets/City_of_Cape_Town"

# Datasets
CHIRPS = "UCSB-CHG/CHIRPS/DAILY"
MODIS_NDVI = "MODIS/061/MOD13Q1"
WORLD_COVER = "ESA/WorldCover/v200"
MODIS_ET = "MODIS/061/MOD16A2GF"
JRC_WATER = "JRC/GSW1_4/GlobalSurfaceWater"
NASADEM = "NASA/NASADEM_HGT/001"
MODIS_LST = "MODIS/061/MOD11A2"

DEFAULT_YEAR = 2024
BASELINE_START = 2001
BASELINE_END = 2020

st.set_page_config(
    page_title=APP_NAME,
    page_icon="30D",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom CSS Styling
st.markdown(
    """
    <style>
      .block-container {padding-top: 1.2rem; padding-bottom: 2rem;}
      .hero {
        padding: 1.2rem 1.4rem;
        border-radius: 14px;
        background: linear-gradient(120deg, #0b3d4f, #147d78);
        color: white;
        margin-bottom: 1rem;
      }
      .hero h1 {color: white; margin-bottom: .25rem;}
      .hero p {color: #e8f6f4; margin-bottom: .2rem;}
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    f"""
    <div class='hero'>
      <h1>30D {APP_NAME}</h1>
      <p><b>{APP_SUBTITLE}</b></p>
      <p>Satellite observations, climate indicators, and spatial decision support for water security.</p>
    </div>
    """,
    unsafe_allow_html=True,
)

# ---------------------------------------------------------------------------
# Earth Engine Initialization & Load Boundary
# ---------------------------------------------------------------------------

@st.cache_resource(show_spinner=False)
def initialize_earth_engine() -> str:
    try:
        ee.Initialize()
        return "initialized"
    except Exception as first_error:
        raise RuntimeError(
            f"Google Earth Engine failed to initialize: {first_error}"
        ) from first_error

@st.cache_resource(show_spinner=True)
def load_aoi():
    initialize_earth_engine()
    fc = ee.FeatureCollection(AOI_ASSET)
    geometry = fc.geometry()
    info = geometry.bounds().getInfo()
    return geometry, info

# ---------------------------------------------------------------------------
# Image Generation Methods
# ---------------------------------------------------------------------------

def year_dates(year: int) -> tuple[str, str]:
    return f"{year}-01-01", f"{year + 1}-01-01"

def annual_chirps(year: int, geometry: ee.Geometry) -> ee.Image:
    start, end = year_dates(year)
    collection = ee.ImageCollection(CHIRPS).filterDate(start, end).filterBounds(geometry).select("precipitation")
    return collection.sum().rename("rainfall_mm").clip(geometry)

def baseline_rainfall(geometry: ee.Geometry) -> ee.Image:
    years = ee.List.sequence(BASELINE_START, BASELINE_END)
    def one_year(y):
        y = ee.Number(y).toInt()
        start = ee.Date.fromYMD(y, 1, 1)
        end = start.advance(1, "year")
        return ee.ImageCollection(CHIRPS).filterDate(start, end).filterBounds(geometry).select("precipitation").sum().rename("rainfall_mm").set("year", y)
    return ee.ImageCollection.fromImages(years.map(one_year)).mean().rename("baseline_rainfall_mm").clip(geometry)

def annual_modis_et(year: int, geometry: ee.Geometry) -> ee.Image:
    start, end = year_dates(year)
    collection = ee.ImageCollection(MODIS_ET).filterDate(start, end).filterBounds(geometry).select("ET")
    return collection.sum().multiply(0.1).rename("et_mm").clip(geometry)

def annual_mean_ndvi(year: int, geometry: ee.Geometry) -> ee.Image:
    start, end = year_dates(year)
    collection = ee.ImageCollection(MODIS_NDVI).filterDate(start, end).filterBounds(geometry).select("NDVI")
    return collection.mean().multiply(0.0001).rename("ndvi").clip(geometry)

def worldcover_image(geometry: ee.Geometry) -> ee.Image:
    return ee.ImageCollection(WORLD_COVER).first().select("Map").rename("landcover").clip(geometry)

def surface_water_image(geometry: ee.Geometry) -> ee.Image:
    # JRC Global Surface Water: Max Water Extent
    return ee.Image(JRC_WATER).select("max_extent").rename("water_mask").clip(geometry)

def elevation_image(geometry: ee.Geometry) -> ee.Image:
    # NASADEM Digital Elevation Model
    return ee.Image(NASADEM).select("elevation").rename("elevation_m").clip(geometry)

def land_surface_temp(year: int, geometry: ee.Geometry) -> ee.Image:
    # MODIS LST Day 8-day composite converted to Celsius (scale factor 0.02, then - 273.15)
    start, end = year_dates(year)
    collection = ee.ImageCollection(MODIS_LST).filterDate(start, end).filterBounds(geometry).select("LST_Day_1km")
    return collection.mean().multiply(0.02).subtract(273.15).rename("lst_c").clip(geometry)

# ---------------------------------------------------------------------------
# Map and Visualizations Setup
# ---------------------------------------------------------------------------

try:
    aoi_geometry, aoi_bounds = load_aoi()
except Exception as e:
    st.error(f"Error initializing map datasets: {e}")
    st.stop()

with st.sidebar:
    st.header("Analysis controls")
    selected_year = st.selectbox(
        "Analysis year",
        options=list(range(2001, dt.date.today().year)),
        index=list(range(2001, dt.date.today().year)).index(DEFAULT_YEAR)
    )
    selected_layer = st.selectbox(
        "Main map layer",
        [
            "Annual precipitation (mm/year)",
            "Baseline rainfall (mm/year)",
            "Vegetation condition — NDVI",
            "ESA WorldCover 2021",
            "Surface Water Presence (JRC)",
            "Digital Elevation Model (NASADEM)",
            "Land Surface Temperature (C)"
        ],
        index=0
    )
    show_boundary = st.checkbox("Show Cape Town boundary", value=True)

# Render dynamic layer
layers = {
    "Annual precipitation (mm/year)": annual_chirps(selected_year, aoi_geometry),
    "Baseline rainfall (mm/year)": baseline_rainfall(aoi_geometry),
    "Vegetation condition — NDVI": annual_mean_ndvi(selected_year, aoi_geometry),
    "ESA WorldCover 2021": worldcover_image(aoi_geometry),
    "Surface Water Presence (JRC)": surface_water_image(aoi_geometry),
    "Digital Elevation Model (NASADEM)": elevation_image(aoi_geometry),
    "Land Surface Temperature (C)": land_surface_temp(selected_year, aoi_geometry)
}

viz_params = {
    "Annual precipitation (mm/year)": {"min": 200, "max": 1200, "palette": ["#f7fbff", "#08306b"]},
    "Baseline rainfall (mm/year)": {"min": 200, "max": 1200, "palette": ["#f7fbff", "#08306b"]},
    "Vegetation condition — NDVI": {"min": 0, "max": 0.8, "palette": ["#ffffff", "#006400"]},
    "ESA WorldCover 2021": {"min": 10, "max": 100, "palette": ["#006400", "#ffbb22", "#ffff4c", "#f00000", "#0000ff"]},
    "Surface Water Presence (JRC)": {"min": 0, "max": 1, "palette": ["#ffffff", "#0d6efd"]},
    "Digital Elevation Model (NASADEM)": {"min": 0, "max": 1000, "palette": ["#000000", "#ffffff"]},
    "Land Surface Temperature (C)": {"min": 15, "max": 35, "palette": ["#313695", "#fdae61", "#d73027"]}
}

map_col, info_col = st.columns([2, 1])

with map_col:
    st.subheader("Interactive Map")
    m = geemap.Map(location=[-34.0, 18.6], zoom_start=10)
    m.addLayer(layers[selected_layer], viz_params[selected_layer], selected_layer)
    if show_boundary:
        m.addLayer(ee.FeatureCollection(AOI_ASSET), {}, "Cape Town Boundary")
    st_folium(m, width=700, height=500, returned_objects=[])

with info_col:
    st.subheader("Indicator Summary")
    st.markdown("Layers have been expanded to enable multi-spectral insights on water basins, surface-water storage, and thermal patterns.")
